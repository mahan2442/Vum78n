import { z } from "zod";
import { requireUser } from "@/lib/auth/require-user";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { requestPayment } from "@/lib/payments/zarinpal";
import { enforceRateLimit } from "@/lib/security/rate-limit";
export const runtime = "nodejs";
const schema = z.object({ planId: z.enum(["plus", "pro"]) });
export async function POST(request: Request) {
  if (process.env.DEMO_MODE === "true") return Response.json({ error: "پرداخت در حالت نمایشی غیرفعال است." }, { status: 409 });
  const auth = await requireUser();
  if (!auth.user) return auth.response!;
  try {
    const rate = await enforceRateLimit(`billing:${auth.user.id}`, 4, 60);
    if (!rate.success) return Response.json({ error: "درخواست‌های پرداخت زیادی ارسال شده؛ کمی بعد تلاش کنید." }, { status: 429, headers: { "Retry-After": "60" } });
  } catch {
    return Response.json({ error: "سامانه محدودیت درخواست در دسترس نیست؛ پرداخت متوقف شد." }, { status: 503 });
  }
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "پلن انتخاب‌شده معتبر نیست." }, { status: 400 });
  const admin = createSupabaseAdminClient();
  const { data: plan, error: planError } = await admin.from("plans").select("id,name,price_irr,is_active").eq("id", parsed.data.planId).maybeSingle();
  if (planError || !plan?.is_active || !Number.isSafeInteger(Number(plan.price_irr)) || Number(plan.price_irr) <= 0) return Response.json({ error: "قیمت این پلن هنوز توسط مدیر تنظیم نشده است." }, { status: 409 });
  const amount = Number(plan.price_irr);
  if (!Number.isSafeInteger(amount) || amount > 1000000000000) return Response.json({ error: "قیمت پلن نامعتبر است." }, { status: 400 });
  const { data: payment, error: insertError } = await admin.from("payments").insert({ user_id: auth.user.id, plan_id: plan.id, amount_irr: amount, status: "pending", idempotency_key: crypto.randomUUID(), request_payload: { plan_id: plan.id } }).select("id").single();
  if (insertError || !payment) return Response.json({ error: "ثبت سفارش پرداخت ناموفق بود." }, { status: 500 });
  const base = process.env.NEXT_PUBLIC_APP_URL;
  if (!base || !base.startsWith("https://") && !base.startsWith("http://localhost")) return Response.json({ error: "آدرس عمومی سایت باید در تنظیمات سرور تعیین شود." }, { status: 503 });
  try {
    const result = await requestPayment({ amountRial: amount, description: `اشتراک ${plan.name} در Mahan AI`, callbackUrl: `${base.replace(/\/$/, "")}/api/billing/callback?paymentId=${payment.id}`, email: auth.user.email });
    const { error } = await admin.from("payments").update({ authority: result.authority, request_payload: { plan_id: plan.id, gateway: "zarinpal" } }).eq("id", payment.id).eq("user_id", auth.user.id);
    if (error) throw new Error("PAYMENT_SAVE_FAILED");
    return Response.json({ paymentUrl: result.paymentUrl });
  } catch (error) {
    await admin.from("payments").update({ status: "failed" }).eq("id", payment.id);
    const msg = error instanceof Error ? error.message : "unknown";
    console.error("zarinpal_request_failed", { paymentId: payment.id, code: msg.split(":")[0] });
    return Response.json({ error: "ساخت درخواست پرداخت ناموفق بود؛ تنظیمات درگاه را بررسی کنید." }, { status: 502 });
  }
}
