import { createSupabaseServerClient } from "@/lib/supabase/server";
export const dynamic = "force-dynamic";
export async function GET() {
  if (process.env.DEMO_MODE === "true") return Response.json({ plans: [{ id: "free", name: "رایگان", price_irr: 0, daily_message_limit: 20 }, { id: "plus", name: "Plus", price_irr: 0, daily_message_limit: 100 }, { id: "pro", name: "Pro", price_irr: 0, daily_message_limit: 300 }], demo: true });
  try {
    const supabase = await createSupabaseServerClient();
    const { data, error } = await supabase.from("plans").select("id,name,price_irr,daily_message_limit,is_active").eq("is_active", true).order("price_irr", { ascending: true });
    if (error) return Response.json({ error: "دریافت پلن‌ها ناموفق بود." }, { status: 500 });
    return Response.json({ plans: data ?? [], demo: false }, { headers: { "Cache-Control": "no-store" } });
  } catch { return Response.json({ error: "تنظیمات پایگاه داده کامل نیست." }, { status: 503 }); }
}
