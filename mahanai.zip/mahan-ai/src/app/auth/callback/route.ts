import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";

export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get("code");
  const next = requestUrl.searchParams.get("next");
  // Allow only same-site relative paths; never accept an absolute redirect.
  const destination = next && next.startsWith("/") && !next.startsWith("//") ? next : "/";

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!code || !supabaseUrl || !supabaseKey) {
    return NextResponse.redirect(new URL("/login?error=callback", requestUrl.origin));
  }

  // Attach auth cookies to the exact redirect response returned below. This is
  // important: cookies written to a separate response can be lost on redirect.
  const response = NextResponse.redirect(new URL(destination, requestUrl.origin));
  const supabase = createServerClient(supabaseUrl, supabaseKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value, options }) => {
          request.cookies.set(name, value);
          response.cookies.set(name, value, options);
        });
      },
    },
  });

  const { error } = await supabase.auth.exchangeCodeForSession(code);
  if (error) {
    // Keep the same response object so any auth-cookie mutations are handled
    // consistently, while sending the user back to a readable error state.
    response.headers.set("Location", new URL("/login?error=callback", requestUrl.origin).toString());
    return response;
  }

  return response;
}
