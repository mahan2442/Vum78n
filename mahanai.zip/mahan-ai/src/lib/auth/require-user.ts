import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function requireUser() {
  const supabase = await createSupabaseServerClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) return { user: null, supabase, response: Response.json({ error: "برای ادامه وارد حساب کاربری شوید." }, { status: 401 }) };
  return { user, supabase, response: null };
}
