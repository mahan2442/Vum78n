export type ProviderId = "openai" | "gemini" | "anthropic" | "deepseek" | "xai" | "mistral" | "openrouter" | "perplexity";
export type ModelCapability = "text" | "vision" | "image" | "reasoning" | "files";

export type ModelDefinition = {
  id: string;
  label: string;
  provider: ProviderId;
  providerLabel: string;
  capabilities: ModelCapability[];
  enabled: boolean;
  envKey: string;
  apiStyle: "openai-compatible" | "anthropic" | "gemini";
  baseUrl: string;
  description: string;
};

const definitions: ModelDefinition[] = [
  { id: "gpt-6-sol", label: "GPT-6 Sol", provider: "openai", providerLabel: "OpenAI", capabilities: ["text", "vision", "files"], enabled: true, envKey: "OPENAI_API_KEY", apiStyle: "openai-compatible", baseUrl: "https://api.openai.com/v1", description: "مدل چندمنظوره قدرتمند" },
  { id: "gpt-6-luna", label: "GPT-6 Luna", provider: "openai", providerLabel: "OpenAI", capabilities: ["text", "vision"], enabled: true, envKey: "OPENAI_API_KEY", apiStyle: "openai-compatible", baseUrl: "https://api.openai.com/v1", description: "گزینه اقتصادی برای استفاده روزمره" },
  { id: "gemini-3.8-flash", label: "Gemini 3.8 Flash", provider: "gemini", providerLabel: "Google", capabilities: ["text", "vision", "files"], enabled: true, envKey: "GEMINI_API_KEY", apiStyle: "gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta", description: "مدل سریع چندرسانه‌ای Google" },
  { id: "claude-sonnet-5", label: "Claude Sonnet 5", provider: "anthropic", providerLabel: "Anthropic", capabilities: ["text", "vision", "files"], enabled: true, envKey: "ANTHROPIC_API_KEY", apiStyle: "anthropic", baseUrl: "https://api.anthropic.com/v1", description: "مدل گفت‌وگویی Anthropic" },
  { id: "deepseek-chat", label: "DeepSeek Chat", provider: "deepseek", providerLabel: "DeepSeek", capabilities: ["text"], enabled: true, envKey: "DEEPSEEK_API_KEY", apiStyle: "openai-compatible", baseUrl: "https://api.deepseek.com/v1", description: "مدل متنی DeepSeek" },
  { id: "grok-4.7", label: "Grok 4.7", provider: "xai", providerLabel: "xAI", capabilities: ["text", "vision"], enabled: true, envKey: "XAI_API_KEY", apiStyle: "openai-compatible", baseUrl: "https://api.x.ai/v1", description: "مدل پرچم‌دار xAI" },
  { id: "mistral-large-latest", label: "Mistral Large", provider: "mistral", providerLabel: "Mistral AI", capabilities: ["text"], enabled: true, envKey: "MISTRAL_API_KEY", apiStyle: "openai-compatible", baseUrl: "https://api.mistral.ai/v1", description: "مدل متنی Mistral" },
  { id: "openai/gpt-4o-mini", label: "OpenRouter · GPT-4o mini", provider: "openrouter", providerLabel: "OpenRouter", capabilities: ["text"], enabled: true, envKey: "OPENROUTER_API_KEY", apiStyle: "openai-compatible", baseUrl: "https://openrouter.ai/api/v1", description: "مدل مسیریابی‌شده؛ هزینه و دسترسی وابسته به حساب OpenRouter است" },
  { id: "sonar-pro", label: "Perplexity Sonar Pro", provider: "perplexity", providerLabel: "Perplexity", capabilities: ["text"], enabled: true, envKey: "PERPLEXITY_API_KEY", apiStyle: "openai-compatible", baseUrl: "https://api.perplexity.ai", description: "مدل جست‌وجومحور Perplexity" }
];

const envFor: Record<string, string | undefined> = {
  OPENAI_API_KEY: process.env.OPENAI_API_KEY,
  GEMINI_API_KEY: process.env.GEMINI_API_KEY,
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY,
  DEEPSEEK_API_KEY: process.env.DEEPSEEK_API_KEY,
  XAI_API_KEY: process.env.XAI_API_KEY,
  MISTRAL_API_KEY: process.env.MISTRAL_API_KEY,
  OPENROUTER_API_KEY: process.env.OPENROUTER_API_KEY,
  PERPLEXITY_API_KEY: process.env.PERPLEXITY_API_KEY
};

/** Server-side availability only. Never expose secrets to the browser. */
export function getAvailableModels() {
  // Always return the public model catalog so the selector remains visible in real mode.
  // Only expose a boolean configuration state; never expose API keys or other secrets.
  return definitions.filter(m => m.enabled).map(({ id, label, provider, providerLabel, capabilities, description, envKey }) => ({
    id, label, provider, providerLabel, capabilities, description,
    configured: process.env.DEMO_MODE !== "false" ? false : Boolean(envFor[envKey])
  }));
}

export function getServerModel(id: string): ModelDefinition | undefined {
  const model = definitions.find(m => m.id === id && m.enabled);
  if (!model) return undefined;
  if (process.env.DEMO_MODE !== "false") return model;
  return envFor[model.envKey] ? model : undefined;
}
