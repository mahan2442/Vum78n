-- Make the current plan catalog usable after applying this migration to an existing database.
update public.plans set enabled_model_ids = array['gpt-6-luna','gpt-6-sol','gemini-3.8-flash','claude-sonnet-5','deepseek-chat','grok-4.7','mistral-large-latest','openai/gpt-4o-mini','sonar-pro'], updated_at = now() where id in ('plus','pro');

-- Harden the auth user trigger with a pinned, empty search path.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'))
  on conflict (id) do nothing;
  return new;
end;
$$;

-- Security hardening: prevent users from changing their own plan or role.
create or replace function public.protect_profile_privileged_fields()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  if auth.uid() is not null and auth.uid() = old.id then
    if new.role is distinct from old.role or new.plan_id is distinct from old.plan_id then
      raise exception 'role_and_plan_are_managed_by_server';
    end if;
  end if;
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists protect_profile_privileged_fields on public.profiles;
create trigger protect_profile_privileged_fields before update on public.profiles
for each row execute procedure public.protect_profile_privileged_fields();

-- Atomic daily quota counter. Each authenticated chat request reserves a slot
-- before a paid provider is called; a failed provider attempt still consumes one slot.
create table if not exists public.daily_usage_counters (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_date date not null default (timezone('utc', now()))::date,
  message_count integer not null default 0 check (message_count >= 0),
  updated_at timestamptz not null default now(),
  primary key (user_id, usage_date)
);
alter table public.daily_usage_counters enable row level security;
-- No direct client policies: writes only via trusted server-side service role RPC call.
create or replace function public.reserve_daily_message(p_user_id uuid, p_limit integer)
returns boolean language plpgsql security definer set search_path = ''
as $$
declare reserved_count integer;
begin
  if p_limit < 1 then return false; end if;
  insert into public.daily_usage_counters(user_id, usage_date, message_count)
  values (p_user_id, (timezone('utc', now()))::date, 1)
  on conflict (user_id, usage_date) do update
    set message_count = public.daily_usage_counters.message_count + 1,
        updated_at = now()
    where public.daily_usage_counters.message_count < p_limit
  returning message_count into reserved_count;
  return reserved_count is not null;
end;
$$;
revoke all on function public.reserve_daily_message(uuid, integer) from public, anon, authenticated;
grant execute on function public.reserve_daily_message(uuid, integer) to service_role;

-- Atomically mark a verified payment paid, activate its subscription and update the profile.
create or replace function public.activate_verified_payment(p_payment_id uuid, p_ref_id text)
returns boolean language plpgsql security definer set search_path = ''
as $$
declare p record; v_now timestamptz := now();
begin
  update public.payments
    set status = 'paid', ref_id = p_ref_id, verified_at = v_now, updated_at = v_now
    where id = p_payment_id and status = 'pending'
    returning user_id, plan_id into p;
  if not found then
    return false;
  end if;
  insert into public.subscriptions(user_id, plan_id, status, starts_at, expires_at)
    values (p.user_id, p.plan_id, 'active', v_now, v_now + interval '30 days');
  update public.profiles set plan_id = p.plan_id, updated_at = v_now where id = p.user_id;
  return true;
end;
$$;
revoke all on function public.activate_verified_payment(uuid, text) from public, anon, authenticated;
grant execute on function public.activate_verified_payment(uuid, text) to service_role;

create or replace function public.current_month_tokens(p_user_id uuid)
returns bigint language sql stable security definer set search_path = ''
as $$
  select coalesce(sum(coalesce(u.input_tokens, 0) + coalesce(u.output_tokens, 0)), 0)::bigint
  from public.usage_records u
  where u.user_id = p_user_id
    and u.status = 'success'
    and u.created_at >= date_trunc('month', now())
$$;
revoke all on function public.current_month_tokens(uuid) from public, anon, authenticated;
grant execute on function public.current_month_tokens(uuid) to service_role;
