-- Mahan AI initial schema. Run with Supabase SQL editor or Supabase CLI.
create extension if not exists pgcrypto;

create type public.payment_status as enum ('pending', 'paid', 'failed', 'refunded');
create type public.message_role as enum ('system', 'user', 'assistant');
create type public.usage_status as enum ('success', 'error', 'blocked');

create table public.plans (
  id text primary key,
  name text not null,
  price_irr bigint not null default 0 check (price_irr >= 0),
  daily_message_limit integer not null default 20 check (daily_message_limit >= 0),
  monthly_token_limit bigint not null default 100000 check (monthly_token_limit >= 0),
  enabled_model_ids text[] not null default '{}',
  monthly_file_limit integer not null default 0 check (monthly_file_limit >= 0),
  monthly_image_limit integer not null default 0 check (monthly_image_limit >= 0),
  priority integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.plans (id, name, price_irr, daily_message_limit, monthly_token_limit, enabled_model_ids, monthly_file_limit, monthly_image_limit)
values
 ('free', 'رایگان', 0, 20, 100000, array['gpt-6-luna'], 2, 0),
 ('plus', 'Plus', 0, 100, 1000000, array['gpt-6-luna','gpt-6-sol','gemini-3.8-flash','claude-sonnet-5','deepseek-chat','grok-4.7','mistral-large-latest','openai/gpt-4o-mini','sonar-pro'], 30, 20),
 ('pro', 'Pro', 0, 300, 5000000, array['gpt-6-luna','gpt-6-sol','gemini-3.8-flash','claude-sonnet-5','deepseek-chat','grok-4.7','mistral-large-latest','openai/gpt-4o-mini','sonar-pro'], 100, 100)
on conflict (id) do nothing;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  plan_id text not null default 'free' references public.plans(id),
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'گفت‌وگوی جدید',
  model_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index conversations_user_updated_idx on public.conversations(user_id, updated_at desc);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.message_role not null,
  content text not null,
  model_id text,
  input_tokens integer,
  output_tokens integer,
  created_at timestamptz not null default now()
);
create index messages_conversation_created_idx on public.messages(conversation_id, created_at);

create table public.providers (
  id text primary key,
  label text not null,
  enabled boolean not null default false,
  health_status text not null default 'unknown',
  config jsonb not null default '{}'::jsonb,
  secret_reference text,
  last_checked_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.models (
  id text primary key,
  provider_id text not null references public.providers(id) on delete cascade,
  label text not null,
  enabled boolean not null default false,
  capabilities text[] not null default array['text'],
  input_cost_per_million numeric(14,6),
  output_cost_per_million numeric(14,6),
  cost_is_estimated boolean not null default true,
  config jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index models_provider_enabled_idx on public.models(provider_id, enabled);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id text not null references public.plans(id),
  status text not null check (status in ('pending','active','expired','cancelled')),
  starts_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index subscriptions_user_status_idx on public.subscriptions(user_id, status, expires_at desc);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subscription_id uuid references public.subscriptions(id),
  plan_id text not null references public.plans(id),
  amount_irr bigint not null check (amount_irr > 0),
  status public.payment_status not null default 'pending',
  provider text not null default 'zarinpal',
  authority text unique,
  ref_id text,
  idempotency_key text not null unique,
  request_payload jsonb not null default '{}'::jsonb,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index payments_user_created_idx on public.payments(user_id, created_at desc);

create table public.usage_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null,
  model text not null,
  input_tokens integer,
  output_tokens integer,
  estimated_cost_usd numeric(14,8),
  cost_is_estimated boolean not null default true,
  status public.usage_status not null,
  created_at timestamptz not null default now()
);
create index usage_user_created_idx on public.usage_records(user_id, created_at desc);
create index usage_model_created_idx on public.usage_records(model, created_at desc);

create table public.uploaded_files (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid references public.conversations(id) on delete cascade,
  storage_path text not null unique,
  original_name text not null,
  mime_type text not null,
  size_bytes bigint not null check (size_bytes > 0),
  processing_status text not null default 'pending' check (processing_status in ('pending','processed','failed')),
  created_at timestamptz not null default now()
);
create index uploaded_files_user_created_idx on public.uploaded_files(user_id, created_at desc);

create table public.admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_type text,
  target_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index admin_audit_created_idx on public.admin_audit_logs(created_at desc);

-- Profile creation trigger; users remain non-admin by default.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'))
  on conflict (id) do nothing;
  return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- RLS: users can access only their own rows. Privileged writes should use trusted server code.
alter table public.plans enable row level security;
alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.providers enable row level security;
alter table public.models enable row level security;
alter table public.subscriptions enable row level security;
alter table public.payments enable row level security;
alter table public.usage_records enable row level security;
alter table public.uploaded_files enable row level security;
alter table public.admin_audit_logs enable row level security;

create policy "active plans are readable" on public.plans for select using (is_active = true);
create policy "profile owner can read" on public.profiles for select using (auth.uid() = id);
create policy "profile owner can update safe fields" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "owner conversations select" on public.conversations for select using (auth.uid() = user_id);
create policy "owner conversations insert" on public.conversations for insert with check (auth.uid() = user_id);
create policy "owner conversations update" on public.conversations for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "owner conversations delete" on public.conversations for delete using (auth.uid() = user_id);
create policy "owner messages select" on public.messages for select using (auth.uid() = user_id);
create policy "owner messages insert" on public.messages for insert with check (auth.uid() = user_id and exists (select 1 from public.conversations c where c.id = conversation_id and c.user_id = auth.uid()));
create policy "owner messages delete" on public.messages for delete using (auth.uid() = user_id);
create policy "owner subscription select" on public.subscriptions for select using (auth.uid() = user_id);
create policy "owner payment select" on public.payments for select using (auth.uid() = user_id);
create policy "owner usage select" on public.usage_records for select using (auth.uid() = user_id);
create policy "owner uploaded files select" on public.uploaded_files for select using (auth.uid() = user_id);
create policy "owner uploaded files insert" on public.uploaded_files for insert with check (auth.uid() = user_id);
create policy "owner uploaded files delete" on public.uploaded_files for delete using (auth.uid() = user_id);
-- No client policies for provider/model configuration or audit logs. Admin APIs must authorize on server.
